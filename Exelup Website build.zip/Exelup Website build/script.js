{\rtf1\ansi\ansicpg1252\cocoartf2708
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 // Select mobile menu toggle button and navigation links\
const menuToggle = document.getElementById('mobile-menu');\
const navLinks = document.querySelector('.nav-links');\
const dropdowns = document.querySelectorAll('.dropdown');\
\
// Toggle mobile menu\
menuToggle.addEventListener('click', () => \{\
  navLinks.classList.toggle('active');\
\});\
\
// Enable dropdown toggle on mobile\
dropdowns.forEach(dropdown => \{\
  dropdown.addEventListener('click', (e) => \{\
    // Prevent link click from immediately closing menu\
    e.stopPropagation();\
    const dropdownContent = dropdown.querySelector('.dropdown-content');\
    \
    // Close all other dropdowns first\
    document.querySelectorAll('.dropdown-content').forEach(content => \{\
      if (content !== dropdownContent) content.style.display = 'none';\
    \});\
\
    // Toggle the clicked dropdown\
    dropdownContent.style.display = \
      dropdownContent.style.display === 'block' ? 'none' : 'block';\
  \});\
\});\
\
// Close dropdowns if clicked outside\
document.addEventListener('click', () => \{\
  document.querySelectorAll('.dropdown-content').forEach(content => \{\
    content.style.display = 'none';\
  \});\
\});\
\
console.log("Website loaded successfully! Navigation is ready.");\
}